package parcial1;
public class Nodo2 {
    public class ListaEnlazadaSimple {
        private static class Nodo {
            int valor;
            Nodo siguiente;

            Nodo(int valor) {
                this.valor = valor;
                this.siguiente = null;
            }
        }

        private Nodo cabeza;

        public ListaEnlazadaSimple() {
            this.cabeza = null;
        }

        public void insertar_inicio(int valor) {
            Nodo nuevoNodo = new Nodo(valor);
            nuevoNodo.siguiente = cabeza;
            cabeza = nuevoNodo;
        }

        public void insertar_final(int valor) {
            Nodo nuevoNodo = new Nodo(valor);
            if (cabeza == null) {
                cabeza = nuevoNodo;
                return;
            }
            Nodo actual = cabeza;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevoNodo;
        }

        public boolean buscar(int valor) {
            Nodo actual = cabeza;
            while (actual != null) {
                if (actual.valor == valor) {
                    return true;
                }
                actual = actual.siguiente;
            }
            return false;
        }

        public void imprimirLista() {
            Nodo actual = cabeza;
            while (actual != null) {
                System.out.print(actual.valor + " -> ");
                actual = actual.siguiente;
            }
            System.out.println("null");
        }

        public void main(String[] args) {
            ListaEnlazadaSimple lista = new ListaEnlazadaSimple();
            lista.insertar_inicio(1);
            lista.insertar_final(2);
            lista.insertar_final(3);
            lista.imprimirLista(); // 1 -> 2 -> 3 -> null

            System.out.println(lista.buscar(2)); // true
            System.out.println(lista.buscar(5)); // false
        }
    }
}