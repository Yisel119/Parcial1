
package parcial1;

 public class Nodo3 {
    public class ListaDoblementeEnlazada {
        private static class Nodo {
            int valor;
            Nodo siguiente;
            Nodo anterior;

            Nodo(int valor) {
                this.valor = valor;
                this.siguiente = null;
                this.anterior = null;
            }
        }

        private Nodo cabeza;
        private Nodo cola;

        public ListaDoblementeEnlazada() {
            this.cabeza = null;
            this.cola = null;
        }

        public void insertar_inicio(int valor) {
            Nodo nuevoNodo = new Nodo(valor);
            if (cabeza == null) {
                cabeza = cola = nuevoNodo;
            } else {
                nuevoNodo.siguiente = cabeza;
                cabeza.anterior = nuevoNodo;
                cabeza = nuevoNodo;
            }
        }

        public void insertar_final(int valor) {
            Nodo nuevoNodo = new Nodo(valor);
            if (cola == null) {
                cabeza = cola = nuevoNodo;
            } else {
                cola.siguiente = nuevoNodo;
                nuevoNodo.anterior = cola;
                cola = nuevoNodo;
            }
        }

        public boolean buscar(int valor) {
            Nodo actual = cabeza;
            while (actual != null) {
                if (actual.valor == valor) {
                    return true;
                }
                actual = actual.siguiente;
            }
            return false;
        }

        // Método para imprimir la lista desde cabeza a cola (opcional)
        public void imprimirLista() {
            Nodo actual = cabeza;
            while (actual != null) {
                System.out.print(actual.valor + " <-> ");
                actual = actual.siguiente;
            }
            System.out.println("null");
        }

        // Ejemplo de uso
        public void main(String[] args) {
            ListaDoblementeEnlazada lista = new ListaDoblementeEnlazada();
            lista.insertar_inicio(10);
            lista.insertar_final(20);
            lista.insertar_inicio(5);
            lista.imprimirLista(); // 5 <-> 10 <-> 20 <-> null

            System.out.println(lista.buscar(20)); // true
            System.out.println(lista.buscar(15)); // false
        }
    }

}
